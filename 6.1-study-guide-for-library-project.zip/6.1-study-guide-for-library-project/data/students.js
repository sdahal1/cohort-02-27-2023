const students = [
    {
        id: 1,
        name: {
            first: "Bugs",
            last: "Bunny"
        }
    },
    {
        id: 2,
        name: {
            first: "Scooby",
            last: "Doo"
        }
    },
    {
        id: 3,
        name: {
            first: "Mickey",
            last: "Mouse"
        }
    },
    {
        id: 4,
        name: {
            first: "Spongebob",
            last: "Squarepants"
        }
    },
    {
        id: 5,
        name: {
            first: "Patrick",
            last: "Star"
        }
    }
]

module.exports = students;